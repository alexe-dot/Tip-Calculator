
//custom function

function calculateTip() {

    // store date of inputs
    let BillAmount = document.getElementById("BillAmount").value;
    let ServiceQuality = document.getElementById("ServiceQuality").value;
    let TotalPeople = document.getElementById("TotalPeople").value;

    // quick validation
    if (BillAmount === "" || ServiceQuality == 0) {
        window.alert("Please enter a value to get this thing up and running");
        return; // this will prevent function to continue
    }

    // check to see if this input isempty or less than or equal to 1

    if (TotalPeople === "" || TotalPeople <= 1) {
        TotalPeople = 1;
        document.getElementById("each").style.display = "none";
    } else {
        document.getElementById("each").style.display = "block";
    }
    //  Do some math

    let total = (BillAmount * ServiceQuality) / TotalPeople;
    total = Math.round(total * 100) / 100;
    total = total.toFixed(2);



    //dispaly tip
    document.getElementById("TotalTip").style.display = "block";
    document.getElementById("tip").innerHTML = total;


}



// Hid ethe tip amount on load
document.getElementById("TotalTip").style.display = "none";
document.getElementById("each").style.display = "none";

//Cliking the button calls our custom function
document.getElementById("calculate").onclick = function () { calculateTip(); };